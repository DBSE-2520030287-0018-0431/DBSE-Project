const API = "/api";

function getToken() {
  return localStorage.getItem("secureToken");
}

function getUser() {
  try {
    return JSON.parse(localStorage.getItem("secureUser"));
  } catch {
    return null;
  }
}

function requireLogin() {
  if (!getToken()) {
    window.location.href = "login.html";
  }
}

function logout() {
  localStorage.removeItem("secureToken");
  localStorage.removeItem("secureUser");
  window.location.href = "login.html";
}

function showMessage(id, text, type = "info") {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = `message ${type}`;
  el.textContent = text;
}

async function apiFetch(url, options = {}) {
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {})
  };

  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(API + url, {
    ...options,
    headers
  });

  const data = await response.json();

  if (response.status === 401) {
    logout();
    return;
  }

  return data;
}

document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");

  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const email = document.getElementById("email").value;
      const password = document.getElementById("password").value;

      const data = await apiFetch("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password })
      });

      if (data && data.success) {
        localStorage.setItem("secureToken", data.token);
        localStorage.setItem("secureUser", JSON.stringify(data.user));
        window.location.href = "dashboard.html";
      } else {
        showMessage("message", data?.message || "Login failed", "error");
      }
    });
  }

  const registerForm = document.getElementById("registerForm");

  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const name = document.getElementById("name").value;
      const email = document.getElementById("email").value;
      const password = document.getElementById("password").value;

      const data = await apiFetch("/auth/register", {
        method: "POST",
        body: JSON.stringify({ name, email, password })
      });

      if (data && data.success) {
        showMessage("message", data.message, "success");
        setTimeout(() => window.location.href = "login.html", 1000);
      } else {
        showMessage("message", data?.message || "Registration failed", "error");
      }
    });
  }

  if (document.getElementById("totalScans")) {
    loadDashboard();
  }

  if (document.getElementById("codeInput")) {
    requireLogin();
  }

  if (document.getElementById("reportsTable")) {
    loadReports();
  }

  const user = getUser();
  if (user) {
    const name = document.getElementById("userName");
    const welcome = document.getElementById("welcome");
    if (name) name.textContent = user.name;
    if (welcome) welcome.textContent = `Welcome, ${user.name} 👋`;
  }
});

async function loadDashboard() {
  requireLogin();

  const data = await apiFetch("/reports/summary");
  if (!data?.success) return;

  document.getElementById("totalScans").textContent = data.summary.totalScans;
  document.getElementById("totalVulnerabilities").textContent = data.summary.totalVulnerabilities;
  document.getElementById("highCount").textContent = data.summary.highCount;

  const box = document.getElementById("recentScans");

  if (!data.recent.length) {
    box.innerHTML = `<div class="empty">No scans yet. Start your first scan.</div>`;
    return;
  }

  box.innerHTML = `
    <table>
      <thead>
        <tr><th>Project</th><th>Date</th><th>Issues</th><th>Action</th></tr>
      </thead>
      <tbody>
        ${data.recent.map(r => `
          <tr>
            <td>${escapeHtml(r.project_name)}</td>
            <td>${new Date(r.scan_date).toLocaleString()}</td>
            <td>${r.issue_count}</td>
            <td><button class="link-btn" onclick="viewReport(${r.id})">View</button></td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

async function startScan() {
  requireLogin();

  const code = document.getElementById("codeInput").value;
  const projectName = document.getElementById("projectName").value || "Untitled Project";

  if (!code.trim()) {
    showMessage("scanMessage", "Please enter some code or configuration.", "error");
    return;
  }

  showMessage("scanMessage", "Scanning...", "info");

  const data = await apiFetch("/scan", {
    method: "POST",
    body: JSON.stringify({ code, projectName })
  });

  if (!data?.success) {
    showMessage("scanMessage", data?.message || "Scan failed", "error");
    return;
  }

  showMessage("scanMessage", "Scan completed successfully.", "success");

  const section = document.getElementById("scanResults");
  section.classList.remove("hidden");

  document.getElementById("scanSummary").textContent =
    `${data.vulnerabilities.length} result(s) detected. Scan ID: #${data.scanId}`;

  document.getElementById("resultCards").innerHTML =
    data.vulnerabilities.map(v => `
      <div class="result-card ${v.severity.toLowerCase()}">
        <div class="result-top">
          <h3>${escapeHtml(v.type)}</h3>
          <span class="severity ${v.severity.toLowerCase()}">${escapeHtml(v.severity)}</span>
        </div>
        <p>${escapeHtml(v.description)}</p>
      </div>
    `).join("");
}

async function loadReports() {
  requireLogin();

  const data = await apiFetch("/reports");
  if (!data?.success) return;

  const box = document.getElementById("reportsTable");

  if (!data.reports.length) {
    box.innerHTML = `<div class="empty">No reports available yet.</div>`;
    return;
  }

  const grouped = {};

  data.reports.forEach(r => {
    if (!grouped[r.id]) {
      grouped[r.id] = {
        id: r.id,
        project_name: r.project_name,
        scan_date: r.scan_date,
        issues: []
      };
    }
    if (r.vulnerability_type) grouped[r.id].issues.push(r);
  });

  box.innerHTML = `
    <table>
      <thead>
        <tr><th>Scan ID</th><th>Project</th><th>Date</th><th>Issues</th><th></th></tr>
      </thead>
      <tbody>
        ${Object.values(grouped).map(r => `
          <tr>
            <td>#${r.id}</td>
            <td>${escapeHtml(r.project_name)}</td>
            <td>${new Date(r.scan_date).toLocaleString()}</td>
            <td>${r.issues.length}</td>
            <td><button class="link-btn" onclick="viewReport(${r.id})">View Report</button></td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

async function viewReport(id) {
  const data = await apiFetch(`/reports/${id}`);
  if (!data?.success) return;

  const box = document.getElementById("reportDetail");
  box.classList.remove("hidden");

  box.innerHTML = `
    <div class="panel-heading">
      <div>
        <h2>Report #${data.report.id}</h2>
        <p>${escapeHtml(data.report.project_name)} • ${new Date(data.report.scan_date).toLocaleString()}</p>
      </div>
      <button class="btn btn-small" onclick="window.print()">Print</button>
    </div>

    ${data.report.vulnerabilities.map(v => `
      <div class="result-card ${v.severity.toLowerCase()}">
        <div class="result-top">
          <h3>${escapeHtml(v.vulnerability_type)}</h3>
          <span class="severity ${v.severity.toLowerCase()}">${escapeHtml(v.severity)}</span>
        </div>
        <p>${escapeHtml(v.description)}</p>
      </div>
    `).join("")}
  `;

  box.scrollIntoView({ behavior: "smooth" });
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
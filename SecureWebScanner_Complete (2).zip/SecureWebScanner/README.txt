SECUREWEB VULNERABILITY DETECTION SYSTEM
=======================================

1. REQUIREMENTS
- Node.js
- MySQL Server
- MySQL Workbench (optional)
- VS Code
- Modern web browser

2. DATABASE
Open MySQL Workbench.
Open database/database.sql.
Run the complete SQL script.

3. MYSQL PASSWORD
Open db.js.
Change:
password: "YOUR_MYSQL_PASSWORD"

to your MySQL root password.

4. INSTALL PACKAGES
Open terminal in the project folder:

npm install

5. START SERVER

node server.js

Open:
http://localhost:5000

6. USE THE WEBSITE
- Register a new account.
- Login.
- Open Dashboard.
- Select New Scan.
- Enter project name.
- Paste sample code.
- Start Scan.
- Open Reports.
- View/print a report.

7. SAFE DEMO INPUT

Example:
const query = "SELECT * FROM users WHERE name = '" + username + "'";

This should demonstrate the educational SQL Injection pattern detector.

Another example:
element.innerHTML = userInput;

This should demonstrate the XSS pattern detector.

8. IMPORTANT
This is an educational static-pattern scanner. It does not perform active attacks against websites and should not be treated as a production security scanner.

9. PROJECT MODULES
- User Interface Design
- User Login and Access Control
- Vulnerability Scanning
- Backend API Development
- Distributed Scan Processing concept
- Database and Data Management
- Security Analysis and Severity Classification
- Report Generation and Dashboard
- System Testing and Integration

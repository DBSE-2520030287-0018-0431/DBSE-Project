const express = require("express");
const db = require("../db");
const scanCode = require("../scanner/vulnerabilityScanner");
const { authMiddleware } = require("../middleware/auth");

const router = express.Router();

router.post("/", authMiddleware, async (req, res) => {
  const { code, projectName } = req.body;

  if (!code || !code.trim()) {
    return res.status(400).json({ success: false, message: "Code/input is required" });
  }

  try {
    const results = scanCode(code);

    const [scanResult] = await db.promise().query(
      "INSERT INTO scans (user_id, project_name, input_text) VALUES (?, ?, ?)",
      [req.user.id, projectName || "Untitled Project", code]
    );

    const scanId = scanResult.insertId;

    for (const item of results) {
      await db.promise().query(
        `INSERT INTO vulnerabilities
        (scan_id, vulnerability_type, severity, description)
        VALUES (?, ?, ?, ?)`,
        [scanId, item.type, item.severity, item.description]
      );
    }

    res.json({
      success: true,
      scanId,
      vulnerabilities: results
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Scan failed" });
  }
});

module.exports = router;
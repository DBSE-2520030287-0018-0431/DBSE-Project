const express = require("express");
const db = require("../db");
const { authMiddleware } = require("../middleware/auth");

const router = express.Router();

router.get("/summary", authMiddleware, async (req, res) => {
  try {
    const [scans] = await db.promise().query(
      "SELECT COUNT(*) AS totalScans FROM scans WHERE user_id = ?",
      [req.user.id]
    );

    const [vulns] = await db.promise().query(
      `SELECT COUNT(*) AS totalVulnerabilities
       FROM vulnerabilities v
       JOIN scans s ON s.id = v.scan_id
       WHERE s.user_id = ? AND v.type NOT LIKE 'No obvious%'`,
      [req.user.id]
    );

    const [high] = await db.promise().query(
      `SELECT COUNT(*) AS highCount
       FROM vulnerabilities v
       JOIN scans s ON s.id = v.scan_id
       WHERE s.user_id = ? AND v.severity = 'High'`,
      [req.user.id]
    );

    const [recent] = await db.promise().query(
      `SELECT s.id, s.project_name, s.scan_date,
              COUNT(v.id) AS issue_count
       FROM scans s
       LEFT JOIN vulnerabilities v ON s.id = v.scan_id
       WHERE s.user_id = ?
       GROUP BY s.id
       ORDER BY s.scan_date DESC
       LIMIT 5`,
      [req.user.id]
    );

    res.json({
      success: true,
      summary: {
        totalScans: scans[0].totalScans,
        totalVulnerabilities: vulns[0].totalVulnerabilities,
        highCount: high[0].highCount
      },
      recent
    });
  } catch {
    res.status(500).json({ success: false, message: "Could not load summary" });
  }
});

router.get("/", authMiddleware, async (req, res) => {
  try {
    const [rows] = await db.promise().query(
      `SELECT s.id, s.project_name, s.scan_date,
              v.vulnerability_type, v.severity, v.description
       FROM scans s
       LEFT JOIN vulnerabilities v ON s.id = v.scan_id
       WHERE s.user_id = ?
       ORDER BY s.scan_date DESC`,
      [req.user.id]
    );

    res.json({ success: true, reports: rows });
  } catch {
    res.status(500).json({ success: false, message: "Could not load reports" });
  }
});

router.get("/:id", authMiddleware, async (req, res) => {
  try {
    const [scan] = await db.promise().query(
      `SELECT id, project_name, scan_date
       FROM scans WHERE id = ? AND user_id = ?`,
      [req.params.id, req.user.id]
    );

    if (!scan.length) {
      return res.status(404).json({ success: false, message: "Report not found" });
    }

    const [vulnerabilities] = await db.promise().query(
      `SELECT vulnerability_type, severity, description
       FROM vulnerabilities WHERE scan_id = ?`,
      [req.params.id]
    );

    res.json({
      success: true,
      report: {
        ...scan[0],
        vulnerabilities
      }
    });
  } catch {
    res.status(500).json({ success: false, message: "Could not load report" });
  }
});

module.exports = router;